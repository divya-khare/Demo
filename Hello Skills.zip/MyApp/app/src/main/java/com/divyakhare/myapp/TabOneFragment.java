package com.divyakhare.myapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class TabOneFragment extends Fragment {
    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    public TabOneFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
          View view = inflater.inflate(R.layout.fragment_tab_one, container, false);
          recyclerView = view.findViewById(R.id.recycler_tab1);
        recyclerTabOne();
        return view;
    }

    private void recyclerTabOne() {
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false));
        //Compile time data
        ArrayList<Tab1Helper> tabData = new ArrayList<>();
        tabData.add(new Tab1Helper(R.drawable.daisy,"Daisy"));
        tabData.add(new Tab1Helper(R.drawable.rose,"Rose"));
        tabData.add(new Tab1Helper(R.drawable.daisy,"Daisy"));
        tabData.add(new Tab1Helper(R.drawable.rose,"Rose"));
        tabData.add(new Tab1Helper(R.drawable.daisy,"Daisy"));
        tabData.add(new Tab1Helper(R.drawable.rose,"Rose"));

        adapter = new Tab1Adaptor(tabData);
        recyclerView.setAdapter(adapter);
    }
}