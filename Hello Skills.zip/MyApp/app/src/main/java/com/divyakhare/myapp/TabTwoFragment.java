package com.divyakhare.myapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
public class TabTwoFragment extends Fragment {
    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    public TabTwoFragment() {
        // Required empty public constructor
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_tab_two, container, false);
        recyclerView = view.findViewById(R.id.recycler_tab2);
        recyclerTabTwo();
        return view;
    }

    private void recyclerTabTwo() {
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
        //Compile time data
        ArrayList<Tab1Helper> tabData = new ArrayList<>();
        tabData.add(new Tab1Helper(R.drawable.tulip,"Tulip"));
        tabData.add(new Tab1Helper(R.drawable.sunflower,"Sunflower"));
        tabData.add(new Tab1Helper(R.drawable.tulip,"Tulip"));
        tabData.add(new Tab1Helper(R.drawable.sunflower,"Sunflower"));
        tabData.add(new Tab1Helper(R.drawable.tulip,"Tulip"));
        tabData.add(new Tab1Helper(R.drawable.sunflower,"Sunflower"));

        adapter = new Tab2Adaptor(tabData);
        recyclerView.setAdapter(adapter);
    }
}