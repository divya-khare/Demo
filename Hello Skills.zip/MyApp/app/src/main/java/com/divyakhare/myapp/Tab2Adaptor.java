package com.divyakhare.myapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class Tab2Adaptor extends RecyclerView.Adapter<Tab2Adaptor.Tab2ViewHolder>
{
    ArrayList<Tab1Helper> tabData2;
    //Constructor
    public Tab2Adaptor(ArrayList<Tab1Helper> tab2Data) {
        this.tabData2 = tab2Data;
    }

    @NonNull
    @Override
    public Tab2ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_tab_two_layout,parent,false);
        Tab2ViewHolder tab2ViewHolder = new Tab2ViewHolder(view);
        return tab2ViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Tab2ViewHolder holder, int position) {
       Tab1Helper tab2Helper = tabData2.get(position);
        holder.title.setText(tab2Helper.getTitle());
        holder.imageView.setImageResource(tab2Helper.getImage());
    }

    @Override
    public int getItemCount() {
        return tabData2.size();
    }

    public static class Tab2ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ImageView imageView;
        public Tab2ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.textView2);
            imageView = itemView.findViewById(R.id.imageView2);
        }
    }
}
