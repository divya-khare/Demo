package com.divyakhare.myapp;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

class PagerAdaptor extends FragmentStatePagerAdapter {
    int noOfTabs;
    public PagerAdaptor(@NonNull FragmentManager fm, int no_of_tabs) {
        super(fm,no_of_tabs);
        noOfTabs = no_of_tabs;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:return new TabOneFragment();
            case 1:return new TabTwoFragment();
            default: return null;}
    }

    @Override
    public int getCount() {
        return noOfTabs;
    }
}
