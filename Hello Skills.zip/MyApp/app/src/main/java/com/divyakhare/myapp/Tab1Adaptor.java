package com.divyakhare.myapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class Tab1Adaptor extends RecyclerView.Adapter<Tab1Adaptor.Tab1ViewHolder>
{
    ArrayList<Tab1Helper> tabData;
    //Constructor
    public Tab1Adaptor(ArrayList<Tab1Helper> tab1Data) {
        this.tabData = tab1Data;
    }

    @NonNull
    @Override
    public Tab1ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_tab_one_layout,parent,false);
        Tab1ViewHolder tab1ViewHolder = new Tab1ViewHolder(view);
        return tab1ViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Tab1ViewHolder holder, int position) {
        Tab1Helper tabHelperClass = tabData.get(position);
        holder.title.setText(tabHelperClass.getTitle());
        holder.imageView.setImageResource(tabHelperClass.getImage());
    }

    @Override
    public int getItemCount() {
        return tabData.size();
    }

    public static class Tab1ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ImageView imageView;
        public Tab1ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.txtTitle);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}
